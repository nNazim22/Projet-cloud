import getpass
import sys

from . import auth, db


def main():
    if len(sys.argv) < 3:
        print("Usage : python -m app.create_admin EMAIL NOM")
        sys.exit(1)
    email = sys.argv[1].strip().lower()
    nom = " ".join(sys.argv[2:])
    mot_de_passe = getpass.getpass("Mot de passe (10 caracteres minimum) : ")
    if len(mot_de_passe) < 10:
        print("Mot de passe trop court.")
        sys.exit(1)
    if mot_de_passe != getpass.getpass("Confirmer : "):
        print("Les deux saisies different.")
        sys.exit(1)
    db.init_db()
    with db.connexion() as conn:
        if conn.execute("SELECT 1 FROM users WHERE email = %s", (email,)).fetchone():
            print("Cette adresse existe deja.")
            sys.exit(1)
        conn.execute(
            "INSERT INTO users (email, nom, password_hash, role) VALUES (%s, %s, %s, 'admin')",
            (email, nom, auth.hacher(mot_de_passe)),
        )
        db.journaliser(conn, None, "admin_cree", email)
    print(f"Administrateur cree : {email}")


main()
