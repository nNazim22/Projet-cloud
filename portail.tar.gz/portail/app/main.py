import os
import re
from contextlib import asynccontextmanager
from decimal import Decimal, InvalidOperation
from pathlib import Path

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from . import auth, db


@asynccontextmanager
async def lifespan(app):
    db.init_db()
    yield


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(
    SessionMiddleware,
    secret_key=os.environ["SECRET_KEY"],
    same_site="lax",
    max_age=8 * 3600,
    https_only=False,  # laboratoire en HTTP ; passer a True derriere HTTPS
)
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def page(request, nom, statut=200, **contexte):
    contexte["csrf"] = auth.jeton_csrf(request.session)
    contexte.setdefault("utilisateur", None)
    return templates.TemplateResponse(request, nom, contexte, status_code=statut)


def verifier_csrf(request, jeton):
    if not auth.csrf_valide(request.session, jeton):
        raise HTTPException(status_code=403, detail="Jeton CSRF invalide")


def exiger_utilisateur(request: Request):
    uid = request.session.get("uid")
    utilisateur = None
    if uid:
        with db.connexion() as conn:
            utilisateur = conn.execute(
                "SELECT * FROM users WHERE id = %s AND actif", (uid,)
            ).fetchone()
    if utilisateur is None:
        request.session.clear()
        raise HTTPException(status_code=303, headers={"Location": "/login"})
    return utilisateur


def exiger_admin(utilisateur=Depends(exiger_utilisateur)):
    if utilisateur["role"] != "admin":
        raise HTTPException(status_code=403, detail="Acces reserve aux administrateurs")
    return utilisateur


@app.get("/")
def racine():
    return RedirectResponse("/accueil", status_code=303)


@app.get("/login")
def login_page(request: Request):
    if request.session.get("uid"):
        return RedirectResponse("/accueil", status_code=303)
    return page(request, "login.html")


@app.post("/login")
def login(
    request: Request,
    email: str = Form(...),
    mot_de_passe: str = Form(...),
    csrf: str = Form(""),
):
    verifier_csrf(request, csrf)
    email = email.strip().lower()
    with db.connexion() as conn:
        if auth.trop_d_echecs(conn, email):
            return page(
                request,
                "login.html",
                statut=429,
                erreur="Trop de tentatives. Reessayez dans quelques minutes.",
            )
        u = conn.execute("SELECT * FROM users WHERE email = %s", (email,)).fetchone()
        hash_stocke = None
        if u and u["actif"] and u["source"] == "local":
            hash_stocke = u["password_hash"]
        if auth.verifier(mot_de_passe, hash_stocke):
            request.session.clear()
            request.session["uid"] = u["id"]
            db.journaliser(conn, u["id"], "login_ok", email)
            return RedirectResponse("/accueil", status_code=303)
        db.journaliser(conn, u["id"] if u else None, "login_echec", email)
    return page(request, "login.html", statut=401, erreur="Identifiants incorrects.")


@app.post("/logout")
def logout(request: Request, csrf: str = Form("")):
    verifier_csrf(request, csrf)
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@app.get("/accueil")
def accueil(request: Request, utilisateur=Depends(exiger_utilisateur)):
    return page(request, "accueil.html", utilisateur=utilisateur)


def liste_utilisateurs():
    with db.connexion() as conn:
        return conn.execute("SELECT * FROM users ORDER BY id").fetchall()


@app.get("/admin/utilisateurs")
def admin_utilisateurs(request: Request, admin=Depends(exiger_admin)):
    return page(
        request,
        "admin_utilisateurs.html",
        utilisateur=admin,
        utilisateurs=liste_utilisateurs(),
    )


@app.post("/admin/utilisateurs")
def admin_creer_utilisateur(
    request: Request,
    admin=Depends(exiger_admin),
    email: str = Form(...),
    nom: str = Form(...),
    entite: str = Form(""),
    mot_de_passe: str = Form(...),
    role: str = Form("client"),
    budget_mensuel: str = Form("0"),
    csrf: str = Form(""),
):
    verifier_csrf(request, csrf)
    email = email.strip().lower()
    nom = nom.strip()
    entite = entite.strip() or None
    erreur = None
    try:
        budget = Decimal(budget_mensuel.replace(",", "."))
    except InvalidOperation:
        budget = None
    if not EMAIL_RE.match(email):
        erreur = "Adresse e-mail invalide."
    elif not nom:
        erreur = "Le nom est obligatoire."
    elif len(mot_de_passe) < 10:
        erreur = "Le mot de passe doit contenir au moins 10 caracteres."
    elif role not in ("client", "admin"):
        erreur = "Role invalide."
    elif budget is None or budget < 0 or budget > 1000000:
        erreur = "Budget invalide."
    if not erreur:
        with db.connexion() as conn:
            if conn.execute("SELECT 1 FROM users WHERE email = %s", (email,)).fetchone():
                erreur = "Cette adresse e-mail existe deja."
            else:
                nouveau = conn.execute(
                    "INSERT INTO users (email, nom, entite, password_hash, role, budget_mensuel) "
                    "VALUES (%s, %s, %s, %s, %s, %s) RETURNING id",
                    (email, nom, entite, auth.hacher(mot_de_passe), role, budget),
                ).fetchone()
                db.journaliser(conn, admin["id"], "utilisateur_cree", f"{email} (id {nouveau['id']})")
    if erreur:
        return page(
            request,
            "admin_utilisateurs.html",
            statut=400,
            utilisateur=admin,
            utilisateurs=liste_utilisateurs(),
            erreur=erreur,
        )
    return RedirectResponse("/admin/utilisateurs", status_code=303)


@app.post("/admin/utilisateurs/{user_id}/actif")
def admin_basculer_actif(
    request: Request,
    user_id: int,
    admin=Depends(exiger_admin),
    csrf: str = Form(""),
):
    verifier_csrf(request, csrf)
    if user_id == admin["id"]:
        raise HTTPException(status_code=400, detail="Vous ne pouvez pas desactiver votre propre compte")
    with db.connexion() as conn:
        u = conn.execute(
            "UPDATE users SET actif = NOT actif WHERE id = %s RETURNING email, actif", (user_id,)
        ).fetchone()
        if u is None:
            raise HTTPException(status_code=404, detail="Utilisateur introuvable")
        db.journaliser(
            conn, admin["id"], "utilisateur_active" if u["actif"] else "utilisateur_desactive", u["email"]
        )
    return RedirectResponse("/admin/utilisateurs", status_code=303)
