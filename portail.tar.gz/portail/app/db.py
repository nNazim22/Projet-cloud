import os
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

DATABASE_URL = os.environ["DATABASE_URL"]


def connexion():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


def init_db():
    schema = (Path(__file__).parent / "schema.sql").read_text()
    with connexion() as conn:
        conn.execute(schema)


def journaliser(conn, user_id, action, detail=None):
    conn.execute(
        "INSERT INTO journal (user_id, action, detail) VALUES (%s, %s, %s)",
        (user_id, action, detail),
    )
