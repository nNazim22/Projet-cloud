import secrets

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

hasher = PasswordHasher()
# Hachage factice : on le vérifie même si l'utilisateur n'existe pas,
# pour que le temps de réponse ne révèle pas si un compte existe.
FAUX_HASH = hasher.hash("mot-de-passe-factice")

MAX_ECHECS = 5
FENETRE_MINUTES = 10


def hacher(mot_de_passe):
    return hasher.hash(mot_de_passe)


def verifier(mot_de_passe, hash_stocke):
    try:
        return hasher.verify(hash_stocke or FAUX_HASH, mot_de_passe) and bool(hash_stocke)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def trop_d_echecs(conn, email):
    ligne = conn.execute(
        "SELECT count(*) AS n FROM journal "
        "WHERE action = 'login_echec' AND detail = %s "
        "AND date > now() - make_interval(mins => %s)",
        (email, FENETRE_MINUTES),
    ).fetchone()
    return ligne["n"] >= MAX_ECHECS


def jeton_csrf(session):
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


def csrf_valide(session, jeton):
    attendu = session.get("csrf")
    return bool(attendu) and bool(jeton) and secrets.compare_digest(attendu, jeton)
