"""Client minimal de l'API de Semaphore (lancer une tache, lire son statut)."""
import json
import os
import urllib.error
import urllib.request


class ErreurSemaphore(Exception):
    pass


def _requete(methode, chemin, corps=None):
    url = os.environ["SEMAPHORE_URL"].rstrip("/") + chemin
    donnees = json.dumps(corps).encode() if corps is not None else None
    req = urllib.request.Request(
        url,
        data=donnees,
        method=methode,
        headers={
            "Authorization": "Bearer " + os.environ["SEMAPHORE_TOKEN"],
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as reponse:
            brut = reponse.read()
    except urllib.error.HTTPError as e:
        raise ErreurSemaphore(f"HTTP {e.code}") from None
    except (urllib.error.URLError, OSError) as e:
        raise ErreurSemaphore(type(e).__name__) from None
    return json.loads(brut) if brut else None


def _projet():
    return os.environ.get("SEMAPHORE_PROJECT", "1")


def lancer(template_id, champs):
    """Lance une tache. Le champ 'environment' doit etre une CHAINE contenant du JSON."""
    corps = {"template_id": int(template_id), "environment": json.dumps(champs)}
    reponse = _requete("POST", f"/api/project/{_projet()}/tasks", corps)
    try:
        return int(reponse["id"])
    except (TypeError, KeyError, ValueError):
        raise ErreurSemaphore("reponse inattendue") from None


def statut_tache(tache_id):
    reponse = _requete("GET", f"/api/project/{_projet()}/tasks/{int(tache_id)}")
    try:
        return str(reponse["status"])
    except (TypeError, KeyError):
        raise ErreurSemaphore("reponse inattendue") from None


def template_creer():
    return int(os.environ.get("SEMAPHORE_TEMPLATE_CREER", "1"))


def template_supprimer():
    return int(os.environ.get("SEMAPHORE_TEMPLATE_SUPPRIMER", "3"))
