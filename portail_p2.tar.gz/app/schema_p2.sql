CREATE TABLE IF NOT EXISTS prix (
    cloud      TEXT NOT NULL,
    taille     TEXT NOT NULL,
    prix_heure NUMERIC(8,4) NOT NULL,
    PRIMARY KEY (cloud, taille)
);

INSERT INTO prix (cloud, taille, prix_heure) VALUES
    ('proxmox', 'small',  0.0200),
    ('proxmox', 'medium', 0.0400),
    ('proxmox', 'large',  0.0800)
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS vms (
    id          SERIAL PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    nom         TEXT NOT NULL,
    nom_complet TEXT NOT NULL,
    cloud       TEXT NOT NULL,
    taille      TEXT NOT NULL,
    ip          TEXT,
    statut      TEXT NOT NULL,
    cree_le     TIMESTAMPTZ NOT NULL DEFAULT now(),
    supprimee_le TIMESTAMPTZ
);

-- Une adresse ne peut servir qu'a une seule VM non supprimee, meme si deux commandes arrivent ensemble
CREATE UNIQUE INDEX IF NOT EXISTS vms_ip_active
    ON vms (ip) WHERE ip IS NOT NULL AND statut <> 'supprimee';
-- Un nom complet est unique par cloud tant que la VM existe
CREATE UNIQUE INDEX IF NOT EXISTS vms_nom_actif
    ON vms (cloud, nom_complet) WHERE statut <> 'supprimee';

CREATE TABLE IF NOT EXISTS actions (
    id       SERIAL PRIMARY KEY,
    vm_id    INTEGER NOT NULL REFERENCES vms(id),
    type     TEXT NOT NULL,
    statut   TEXT NOT NULL DEFAULT 'waiting',
    tache_id INTEGER,
    debut    TIMESTAMPTZ NOT NULL DEFAULT now(),
    fin      TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS actions_en_cours ON actions (id) WHERE fin IS NULL;
