"""Catalogue, commande, suivi et suppression des VM (P2)."""
import os
import re
import threading

import psycopg
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import RedirectResponse

from . import db, sem

NOM_RE = re.compile(r"^[a-z][a-z0-9-]{1,19}$")
PLAGE_IP = [f"172.16.117.{n}" for n in range(170, 180)]
FINAUX_OK = {"success"}
FINAUX_ECHEC = {"error", "stopped"}
STATUTS = {
    "creation": "En creation",
    "prete": "Prete",
    "echec": "Echec",
    "suppression": "Suppression en cours",
    "supprimee": "Supprimee",
}


class NomPris(Exception):
    pass


class PlusDIp(Exception):
    pass


def clouds_actifs():
    return [c.strip() for c in os.environ.get("CLOUDS_ACTIFS", "proxmox").split(",") if c.strip()]


def tarifs(conn):
    actifs = clouds_actifs()
    lignes = conn.execute("SELECT * FROM prix ORDER BY cloud, prix_heure").fetchall()
    return [l for l in lignes if l["cloud"] in actifs]


def reserver(conn, user_id, nom, nom_complet, cloud, taille):
    """Insere la VM avec la premiere adresse libre. L'index unique tranche en cas de course."""
    if cloud == "proxmox":
        utilisees = {
            r["ip"]
            for r in conn.execute(
                "SELECT ip FROM vms WHERE ip IS NOT NULL AND statut <> 'supprimee'"
            ).fetchall()
        }
        candidates = [ip for ip in PLAGE_IP if ip not in utilisees]
    else:
        candidates = [None]  # AWS attribue l'adresse
    for ip in candidates:
        try:
            with conn.transaction():
                ligne = conn.execute(
                    "INSERT INTO vms (user_id, nom, nom_complet, cloud, taille, ip, statut) "
                    "VALUES (%s, %s, %s, %s, %s, %s, 'creation') RETURNING id",
                    (user_id, nom, nom_complet, cloud, taille, ip),
                ).fetchone()
                return ligne["id"], ip
        except psycopg.errors.UniqueViolation as e:
            if e.diag.constraint_name == "vms_nom_actif":
                raise NomPris() from None
            continue
    raise PlusDIp()


def synchroniser():
    """Interroge Semaphore pour chaque action en cours et met la base a jour."""
    with db.connexion() as conn:
        actions = conn.execute(
            "SELECT a.id, a.type, a.statut, a.tache_id, a.vm_id, v.user_id, v.nom_complet "
            "FROM actions a JOIN vms v ON v.id = a.vm_id "
            "WHERE a.fin IS NULL AND a.tache_id IS NOT NULL ORDER BY a.id"
        ).fetchall()
        for a in actions:
            try:
                statut = sem.statut_tache(a["tache_id"])
            except sem.ErreurSemaphore:
                continue
            if statut in FINAUX_OK or statut in FINAUX_ECHEC:
                ok = statut in FINAUX_OK
                conn.execute(
                    "UPDATE actions SET statut = %s, fin = now() WHERE id = %s", (statut, a["id"])
                )
                if a["type"] == "creation":
                    nouveau = "prete" if ok else "echec"
                    conn.execute("UPDATE vms SET statut = %s WHERE id = %s", (nouveau, a["vm_id"]))
                elif ok:
                    conn.execute(
                        "UPDATE vms SET statut = 'supprimee', supprimee_le = now() WHERE id = %s",
                        (a["vm_id"],),
                    )
                else:
                    conn.execute("UPDATE vms SET statut = 'echec' WHERE id = %s", (a["vm_id"],))
                db.journaliser(
                    conn,
                    a["user_id"],
                    f"vm_{a['type']}_{'ok' if ok else 'echec'}",
                    f"{a['nom_complet']} (tache {a['tache_id']}, {statut})",
                )
            elif statut != a["statut"]:
                conn.execute("UPDATE actions SET statut = %s WHERE id = %s", (statut, a["id"]))
            conn.commit()


_arret = threading.Event()


def _boucle():
    while not _arret.wait(5):
        try:
            synchroniser()
        except Exception as e:  # le suivi ne doit jamais s'arreter
            print("suivi:", type(e).__name__, flush=True)


def demarrer_suivi():
    if os.environ.get("SUIVI_AUTO", "1") == "1":
        _arret.clear()
        threading.Thread(target=_boucle, daemon=True).start()


def arreter_suivi():
    _arret.set()


def creer_routeur(page, exiger_utilisateur, verifier_csrf):
    r = APIRouter()

    def formulaire(request, utilisateur, statut=200, **extra):
        with db.connexion() as conn:
            lignes = tarifs(conn)
        return page(
            request, "catalogue.html", statut=statut, utilisateur=utilisateur, tarifs=lignes, **extra
        )

    @r.get("/catalogue")
    def catalogue(request: Request, utilisateur=Depends(exiger_utilisateur)):
        return formulaire(request, utilisateur)

    @r.post("/catalogue")
    def commander(
        request: Request,
        utilisateur=Depends(exiger_utilisateur),
        nom: str = Form(...),
        cloud: str = Form("proxmox"),
        taille: str = Form(...),
        csrf: str = Form(""),
    ):
        verifier_csrf(request, csrf)
        nom = nom.strip().lower()
        if cloud not in clouds_actifs():
            return formulaire(request, utilisateur, 400, erreur="Cloud indisponible.")
        if not NOM_RE.match(nom):
            return formulaire(
                request, utilisateur, 400,
                erreur="Nom invalide : 2 a 20 caracteres, minuscules, chiffres et tirets, commence par une lettre.",
            )
        nom_complet = f"u{utilisateur['id']}-{nom}"
        try:
            with db.connexion() as conn:
                if not conn.execute(
                    "SELECT 1 FROM prix WHERE cloud = %s AND taille = %s", (cloud, taille)
                ).fetchone():
                    return formulaire(request, utilisateur, 400, erreur="Taille indisponible pour ce cloud.")
                vm_id, ip = reserver(conn, utilisateur["id"], nom, nom_complet, cloud, taille)
                action = conn.execute(
                    "INSERT INTO actions (vm_id, type) VALUES (%s, 'creation') RETURNING id", (vm_id,)
                ).fetchone()["id"]
                db.journaliser(conn, utilisateur["id"], "vm_commande", f"{nom_complet} {cloud} {taille} {ip or ''}".strip())
        except NomPris:
            return formulaire(request, utilisateur, 409, erreur="Vous avez deja une VM avec ce nom.")
        except PlusDIp:
            return formulaire(request, utilisateur, 409, erreur="Plus d'adresse disponible dans la plage .170 a .179.")
        champs = {"cloud": cloud, "name": nom_complet, "size": taille}
        if ip:
            champs["ip"] = ip
        try:
            tache = sem.lancer(sem.template_creer(), champs)
        except sem.ErreurSemaphore as e:
            # Rien n'a ete lance : on libere l'adresse
            with db.connexion() as conn:
                conn.execute("UPDATE vms SET statut = 'supprimee', supprimee_le = now() WHERE id = %s", (vm_id,))
                conn.execute("UPDATE actions SET statut = 'error', fin = now() WHERE id = %s", (action,))
                db.journaliser(conn, utilisateur["id"], "vm_lancement_echec", f"{nom_complet} ({e})")
            return formulaire(request, utilisateur, 502, erreur="Le moteur de creation est injoignable. Reessayez plus tard.")
        with db.connexion() as conn:
            conn.execute("UPDATE actions SET tache_id = %s WHERE id = %s", (tache, action))
        return RedirectResponse("/vms", status_code=303)

    @r.get("/vms")
    def mes_vms(request: Request, utilisateur=Depends(exiger_utilisateur)):
        admin = utilisateur["role"] == "admin"
        with db.connexion() as conn:
            vms = conn.execute(
                "SELECT v.*, u.email FROM vms v JOIN users u ON u.id = v.user_id "
                "WHERE (%s OR v.user_id = %s) ORDER BY (v.statut = 'supprimee'), v.id DESC LIMIT 100",
                (admin, utilisateur["id"]),
            ).fetchall()
        en_cours = any(v["statut"] in ("creation", "suppression") for v in vms)
        return page(
            request, "mes_vms.html", utilisateur=utilisateur, vms=vms, statuts=STATUTS,
            admin=admin, en_cours=en_cours,
        )

    def vm_autorisee(conn, vm_id, utilisateur):
        vm = conn.execute("SELECT * FROM vms WHERE id = %s FOR UPDATE", (vm_id,)).fetchone()
        if vm is None or (vm["user_id"] != utilisateur["id"] and utilisateur["role"] != "admin"):
            raise HTTPException(status_code=404, detail="VM introuvable")
        return vm

    @r.post("/vms/{vm_id}/supprimer")
    def supprimer(
        request: Request, vm_id: int, utilisateur=Depends(exiger_utilisateur), csrf: str = Form("")
    ):
        verifier_csrf(request, csrf)
        with db.connexion() as conn:
            vm = vm_autorisee(conn, vm_id, utilisateur)
            if vm["statut"] not in ("prete", "echec"):
                raise HTTPException(status_code=409, detail="Cette VM ne peut pas etre supprimee maintenant")
            precedent = vm["statut"]
            conn.execute("UPDATE vms SET statut = 'suppression' WHERE id = %s", (vm_id,))
            action = conn.execute(
                "INSERT INTO actions (vm_id, type) VALUES (%s, 'suppression') RETURNING id", (vm_id,)
            ).fetchone()["id"]
            db.journaliser(conn, utilisateur["id"], "vm_suppression_demandee", vm["nom_complet"])
        try:
            tache = sem.lancer(sem.template_supprimer(), {"cloud": vm["cloud"], "name": vm["nom_complet"]})
        except sem.ErreurSemaphore as e:
            with db.connexion() as conn:
                conn.execute("UPDATE vms SET statut = %s WHERE id = %s", (precedent, vm_id))
                conn.execute("UPDATE actions SET statut = 'error', fin = now() WHERE id = %s", (action,))
                db.journaliser(conn, utilisateur["id"], "vm_lancement_echec", f"{vm['nom_complet']} ({e})")
            raise HTTPException(status_code=502, detail="Le moteur est injoignable. Reessayez plus tard.")
        with db.connexion() as conn:
            conn.execute("UPDATE actions SET tache_id = %s WHERE id = %s", (tache, action))
        return RedirectResponse("/vms", status_code=303)

    @r.post("/vms/{vm_id}/liberer")
    def liberer(
        request: Request, vm_id: int, utilisateur=Depends(exiger_utilisateur), csrf: str = Form("")
    ):
        """Admin : libere l'adresse d'une VM en echec dont aucune ressource n'existe (verifier avant)."""
        verifier_csrf(request, csrf)
        if utilisateur["role"] != "admin":
            raise HTTPException(status_code=403, detail="Acces reserve aux administrateurs")
        with db.connexion() as conn:
            vm = vm_autorisee(conn, vm_id, utilisateur)
            if vm["statut"] != "echec":
                raise HTTPException(status_code=409, detail="Seules les VM en echec peuvent etre liberees")
            conn.execute(
                "UPDATE vms SET statut = 'supprimee', supprimee_le = now() WHERE id = %s", (vm_id,)
            )
            db.journaliser(conn, utilisateur["id"], "vm_liberee", vm["nom_complet"])
        return RedirectResponse("/vms", status_code=303)

    return r
