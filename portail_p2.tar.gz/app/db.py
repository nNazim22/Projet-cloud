import os
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

DATABASE_URL = os.environ["DATABASE_URL"]


def connexion():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


def init_db():
    dossier = Path(__file__).parent
    with connexion() as conn:
        for fichier in ("schema.sql", "schema_p2.sql"):
            conn.execute((dossier / fichier).read_text())


def journaliser(conn, user_id, action, detail=None):
    conn.execute(
        "INSERT INTO journal (user_id, action, detail) VALUES (%s, %s, %s)",
        (user_id, action, detail),
    )
